<html>
<title>Checkout</title>
  <!--<head>-->
  <!--  <script type="text/javascript"-->
  <!--          src="https://app.sandbox.midtrans.com/snap/snap.js"-->
  <!--          data-client-key="SB-Mid-client-8js80Oqh6HUWMC4y"></script>-->
  <!--  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>-->
  <!--</head>-->
  <body>

    
    <form id="payment-form" method="post" action="/snap/finish">
      <input type="hidden" name="result_type" id="result-type" value=""></div>
      <input type="hidden" name="result_data" id="result-data" value=""></div>
      <input type="text" name="nominal" id="nominal" value="<?=$nominal?>"></div>
    </form>
    
    <!-- <button id="pay-button">Pay!</button> -->
    


</body>
</html>