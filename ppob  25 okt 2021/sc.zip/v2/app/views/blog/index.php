<main>
    <div class="container-fluid">
        <div class="row">
            <div class="col-12" style="margin-top: 15px;">
                <div class="mb-2">
                    <h1>Blog</h1>
                </div>
                <div class="separator mb-5"></div>
            </div>
        </div>
    </div>
</main>
