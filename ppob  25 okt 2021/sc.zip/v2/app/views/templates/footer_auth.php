<script src="<?= BASEURL; ?>js/jquery.min.js"></script>
<script src="<?= BASEURL; ?>js/popper.min.js"></script>
<script src="<?= BASEURL; ?>js/bootstrap.min.js"></script>
<script src="<?= BASEURL; ?>js/main_login.js"></script>
</body>

</html>