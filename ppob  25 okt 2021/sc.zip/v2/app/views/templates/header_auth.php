<!DOCTYPE html>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="author" content="Wahyu Adi Suryanto">
    <meta name="description" content="Solusi Media adalah Pusat Reseller Produk Digital penyedia Layanan Social Media dan Pulsa All Operator seperti Kebutuhan Instagram, Facebook, Youtube, netflix Premium,youtube premium,spotify premium, dan sebagainya.">
    <meta name="keywords" content="Solusi Media adalah Pusat Reseller Produk Digital penyedia Layanan Social Media dan Pulsa All Operator seperti Kebutuhan Instagram, Facebook, Youtube, netflix Premium,youtube premium,spotify premium, dan sebagainya.">
    <title><?= $data['title']; ?></title>
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/fontawesome-all.min.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/iofrm-style.css">
    <link rel="stylesheet" type="text/css" href="<?= BASEURL; ?>css/iofrm-theme10.css">

</head>

<body>