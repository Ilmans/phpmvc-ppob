<?php

date_default_timezone_set('Asia/jakarta');

define('DB_HOST', 'localhost');
define('DB_NAME', 'v2');
define('DB_USER', 'root');
define('DB_PASS', '');
define('BASEURL', 'http://192.168.1.7/v2/public/');
define('WEB_NAME', 'M Pedia');



$ttt = new DateTime();
$date = date('Y-m-d');
$time = date('H:i:s');

define('DATE', $date);
define('TIME', $time);


//error_reporting(0);
